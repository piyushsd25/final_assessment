package solution;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Userinterface {
	Stage theStage;
	/**********************************************************************************************
	 * 
	 * Attributes
	 * 
	 **********************************************************************************************/

	/*
	 * Constants used to parameterize the graphical user interface. We do not use a
	 * layout manager for this application. Rather we manually control the location
	 * of each graphical element for exact control of the look and feel.
	 */
	private final double BUTTON_WIDTH = 60;
	private final double BUTTON_OFFSET = BUTTON_WIDTH / 2;

	// These are the application values required by the user interface
	private Label label_Doublemainline = new Label("Final Assessment");
	private Label enter = new Label("Enter Roll_No");

	
	
	private Button add = new Button("Add Record");
	private Button delete = new Button("Delete Record");
	private Button modify = new Button("Modify Record");
	private Button submit = new Button("Submit Record");
	private Button generate = new Button("Generate PDF");

	
	TextField delete_text = new TextField();
	TextField nf = new TextField();
	TextField fnf = new TextField();
	TextField mnf = new TextField();
	TextField cf = new TextField();
	TextField sf = new TextField();
	TextField yf = new TextField();

	private double buttonSpace;

	public Userinterface(Pane theRoot, Stage Stage) throws FileNotFoundException, ClassNotFoundException, DocumentException, SQLException {

		// There are five gaps. Compute the button space accordingly.
		buttonSpace = mainline.WINDOW_WIDTH / 5;

		enter.setVisible(false);
		delete_text.setVisible(false);
		
		// Label theScene with the name of the mainline, centered at the top of the pane
		setupLabelUI(label_Doublemainline, "Arial", 24, mainline.WINDOW_WIDTH, Pos.CENTER, 0, 10);

		setupLabelUI(enter, "Arial", 17, mainline.WINDOW_WIDTH, Pos.CENTER, -30, 160);

		// Button UI
		setupButtonUI(add, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.3 * buttonSpace - BUTTON_OFFSET-250,
				300);
		
		setupButtonUI(delete, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.3 * buttonSpace - BUTTON_OFFSET-100,
				300);
		setupButtonUI(modify, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.3 * buttonSpace - BUTTON_OFFSET+50,
				300);
		setupButtonUI(submit, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.3 * buttonSpace - BUTTON_OFFSET+50,
				330);
		setupButtonUI(generate, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.3 * buttonSpace - BUTTON_OFFSET+200,
				300);

	

		
		add.setOnAction((event) -> {	
			try {
				exceltomysql();
			} catch (ClassNotFoundException | NullPointerException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	);
		generate.setOnAction((event) -> {	
			try {
				try {
					dbtopdf();
				} catch (FileNotFoundException | ClassNotFoundException | DocumentException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (NullPointerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	);
		
		delete.setOnAction((event) -> {	
			delete_text.setVisible(true);
			enter.setVisible(true);
			try {
				
				try {
					deleteaction();
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (NullPointerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	);
		
		modify.setOnAction((event) -> {	
			delete_text.setVisible(true);
			enter.setVisible(true);
			try {
				
				try {
					modifyaction();
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (NullPointerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	);
		
		delete_text.setLayoutX(300);
		delete_text.setLayoutY(200);	
		
		

		// Place all of the just-initialized GUI elements into the pane
		theRoot.getChildren().addAll(label_Doublemainline, add,delete,generate,modify,delete_text,enter);

	}
	
	
	

	private void modifyaction() throws ClassNotFoundException, SQLException {
		String roll = delete_text.getText();
		Class.forName("com.mysql.cj.jdbc.Driver");
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","piyushji25");
	       Statement st=con.createStatement();
	       st.execute("Use final_assessment" );
	       ResultSet rs=st.executeQuery("select Name, Father_Name, Mother_Name, Course, Semester, Year from student where Roll_No =" + "'" + roll + "'" );
	       String n =(rs.getString("Name"));
	       String fn=(rs.getString("Father_Name"));
	       String mn=(rs.getString("Mother_Name"));
	       String c=(rs.getString("Course"));
	       String s=(rs.getString("Semester"));
	       String y=(rs.getString("year"));
	       
	      System.out.println(n+ fn+ mn+c+ s+ y);


	       
	}




	private void deleteaction() throws ClassNotFoundException, SQLException {
		if(delete_text.equals(null))
		{
			System.out.println("Kindly! please enter some value");
		}
		else {
			String roll = delete_text.getText();
			Class.forName("com.mysql.cj.jdbc.Driver");
		    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","piyushji25");
		       Statement st=con.createStatement();
		       st.execute("Use final_assessment" );
		       st.execute("delete from student where Roll_no =" + "'" + roll + "'" );
		       
		}

		

	}




	private void dbtopdf() throws FileNotFoundException, DocumentException, ClassNotFoundException, SQLException {
		Document document=new Document();
	       PdfWriter.getInstance(document,new FileOutputStream("C://Users/acer/Desktop/data.pdf"));
	       document.open();
	       
	       PdfPTable table=new PdfPTable(4);
	       table.addCell("Reg_No");
	       table.addCell("Roll_No");
	       table.addCell("Name");
	       table.addCell("Father_Name");
	       table.addCell("Mother_name");
	       table.addCell("Course");
	       table.addCell("Semester");
	       table.addCell("Year");
	       Class.forName("com.mysql.cj.jdbc.Driver");
	       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/final_assessment", "root", "piyushji25");
	       Statement st=con.createStatement();
	       ResultSet rs=st.executeQuery("Select * from student");
	       while(rs.next()){
		   table.addCell(rs.getString("Reg_no"));
	       table.addCell(rs.getString("Roll_no"));
	       table.addCell(rs.getString("Name"));
	       table.addCell(rs.getString("Father_Name"));
	       table.addCell(rs.getString("Mother_Name"));
	       table.addCell(rs.getString("Course"));
	       table.addCell(rs.getString("Semester"));
	       table.addCell(rs.getString("year"));

	       }
	       System.out.println("PDF has been generate successfully");
	       document.add(table);
	       document.close();
	}
	
	
	
	private void exceltomysql() throws SQLException, ClassNotFoundException, NullPointerException{
		String b= null;
		FileChooser FChooser = new FileChooser(); 

File selectedFile = FChooser.showOpenDialog(theStage); 
String fileName = selectedFile.getName().toString();
if (fileName.toLowerCase().endsWith(".xls") && !fileName.toLowerCase().startsWith("~$")) {
b= selectedFile.getAbsolutePath();
} else {
b= null;

}
		


try{
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","piyushji25");
    con.setAutoCommit(false);
    PreparedStatement pstm = null ;
    PreparedStatement pstm1 = null ;
    PreparedStatement pstm2 = null ;
    PreparedStatement pstm3 = null ;
    PreparedStatement pstm6 = null ;

    FileInputStream input = new FileInputStream(b);
    POIFSFileSystem fs = new POIFSFileSystem( input );
    @SuppressWarnings("resource")
HSSFWorkbook wb = new HSSFWorkbook(fs);
    HSSFSheet sheet = wb.getSheetAt(0);
    Row row;
    try {
    String sql6 = "create database final_assessment";
    pstm6 = (PreparedStatement) con.prepareStatement(sql6);
    
    pstm6.execute();}
    catch(Exception e) {
    	System.out.println("already present");
    }
    String sql3 = "Use final_assessment";




         String sql1 = "Create table student(Reg_no int, Roll_no int, Name Varchar(100), Father_Name Varchar(100), Mother_Name Varchar(100), Course Varchar(100), Semester int, year int)";
         pstm3 = (PreparedStatement) con.prepareStatement(sql3);
      //   pstm = (PreparedStatement) con.prepareStatement(sql);
         pstm1 = (PreparedStatement) con.prepareStatement(sql1);
         try {
         pstm3.execute();}
         catch(Exception e) {
         	System.out.println("Database already present");
         }
      //  pstm.execute();
         try {
        pstm1.execute();
         } catch(Exception e) {
         	System.out.println("Table already present");
         }
    
   
    for(int i=1; i<=sheet.getLastRowNum(); i++){
        row = sheet.getRow(i);
        int registration = (int) row.getCell(0).getNumericCellValue();
        int rollno = (int) row.getCell(1).getNumericCellValue();
        String name = row.getCell(2).getStringCellValue();
        String father = row.getCell(3).getStringCellValue();
        String mother = row.getCell(4).getStringCellValue();
        String course = row.getCell(5).getStringCellValue();
        int semester = (int) row.getCell(6).getNumericCellValue();
        int year = (int) row.getCell(7).getNumericCellValue();
        
        
    
        String sql2 = "INSERT INTO student VALUES('"+registration+"','"+rollno+"','"+name+"','"+father+"','"+mother+"','"+course+"','"+semester+"','"+year+"')";

        pstm2 = (PreparedStatement) con.prepareStatement(sql2);

    

        pstm2.execute();
        System.out.println("Import rows "+i);
    }
    con.commit();
    pstm1.close();

    pstm2.close();
    pstm3.close();
    pstm6.close();

    con.close();
    input.close();
    System.out.println("Success import excel to mysql table");
}catch(ClassNotFoundException e){
    System.out.println(e);
}catch(SQLException ex){
    System.out.println(ex);
}catch(IOException ioe){
    System.out.println(ioe);
}

}





	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	/**********************************************************************************************
	 * 
	 * User Interface Actions
	 * 
	 **********************************************************************************************/

	
}